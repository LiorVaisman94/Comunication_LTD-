from django.db import models
from django.contrib.auth.models import User
from django.db.models.signals import post_save
from django.dispatch import receiver

# Profile model to store user-specific information
class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)  # Links Profile to User
    reset_token = models.CharField(max_length=100, blank=True, null=True)  # Field for password reset token
    # Add other fields if needed, for example:
    # phone_number = models.CharField(max_length=15, blank=True)

    def __str__(self):
        return self.user.username



from django.db import models

class NewClient(models.Model):
    idnew_client = models.IntegerField(primary_key=True)  # Define the primary key field as it is in your database
    new_client_name = models.CharField(max_length=45)
    new_client_email = models.EmailField(max_length=45)
    new_client_sin = models.CharField(max_length=45)

    class Meta:
        db_table = 'new_client'  # The exact name of your table in the database
        managed = False  # Indicates that Django should not create or modify this table

    def __str__(self):
        return f"{self.new_client_name} ({self.new_client_email})"



# views.py

# Imports
import hashlib
import json
import os
import random
import re
import string
from Mysite.models import NewClient

from django.conf import settings
from django.contrib import messages
from django.contrib.auth import authenticate, login, logout, update_session_auth_hash
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.hashers import make_password
from django.contrib.auth.models import User
from django.core.mail import send_mail
from django.db import connection, transaction
from django.http import HttpResponse, JsonResponse
from django.shortcuts import render, redirect
from django.templatetags.static import static

# Import certificate utility functions
from Mysite.certificate_utils import load_certificate_from_file, load_public_key_from_file, verify_certificate

# Load Password Policy
def load_password_policy():
    """Load password policy from a JSON file."""
    json_path = r'C:\Users\ליאור\Mysite\static\password_config.json'
    with open(json_path, 'r', encoding='utf-8') as file:
        return json.load(file)

def validate_password(password, policy):
    """Validate a password against the provided policy."""
    # Check password length
    if len(password) < policy['password_length']:
        return False

    # Check complexity requirements
    if policy['password_complexity']['uppercase'] and not re.search(r'[A-Z]', password):
        return False
    if policy['password_complexity']['lowercase'] and not re.search(r'[a-z]', password):
        return False
    if policy['password_complexity']['digits'] and not re.search(r'\d', password):
        return False
    if policy['password_complexity']['special_characters'] and not re.search(r'[\W_]', password):
        return False

    # Check for disallowed words
    for word in policy['disallowed_words']:
        if word.lower() in password.lower():
            return False

    return True

# Register View
def register(request):
    """Handle user registration with password validation."""
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password1 = request.POST['password1']
        password2 = request.POST['password2']
        
        password_policy = load_password_policy()  # Load password policy

        # Validate if passwords match
        if password1 == password2:
            # Validate the password against the policy
            if not validate_password(password1, password_policy):
                messages.error(request, "Not valid data")  # Generic error message
                return render(request, 'register.html')

            # Check if username or email already exists
            if User.objects.filter(username=username).exists():
                messages.error(request, "Not valid data")  # Generic error message
            elif User.objects.filter(email=email).exists():
                messages.error(request, "Not valid data")  # Generic error message
            else:
                # Create user if all validations pass
                user = User.objects.create_user(username=username, password=password1, email=email)
                user.save()
                messages.success(request, 'User created successfully')
                login(request, user)
                return redirect('base')  # Redirect to the homepage after successful registration
        else:
            messages.error(request, "Not valid data")  # Generic error message

    return render(request, 'register.html')

import json
from django.contrib.auth.models import User
from django.contrib.auth import authenticate, login
from django.contrib import messages
from django.shortcuts import render, redirect

# Load configuration from JSON file
with open(r"C:\Users\ליאור\Mysite\static\password_config.json", "r") as config_file:
    config = json.load(config_file)

# Get the login attempts limit from the configuration
MAX_LOGIN_ATTEMPTS = config.get("login_attempts_limit", 3)  # Default to 3 if not found


def login_view(request):
    """Handle user login with login attempt limit."""
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        try:
            # Retrieve the user and check if the user exists
            user = User.objects.get(username=username)

            # Check if the user is blocked due to too many failed login attempts
            if user.profile.login_attempts >= MAX_LOGIN_ATTEMPTS:  # Assuming you have a 'login_attempts' field in user profile
                messages.error(request, 'Too many failed login attempts. Please try again later.')
                return render(request, 'login.html')

            # Activate inactive user (optional, remove if not needed)
            if not user.is_active:
                user.is_active = True
                user.save()

        except User.DoesNotExist:
            messages.error(request, 'Invalid username or password.')
            return render(request, 'login.html')

        # Authenticate the user
        user = authenticate(request, username=username, password=password)
        if user is not None:
            # Reset login attempts on successful login
            user.profile.login_attempts = 0
            user.profile.save()
            
            # Log the user in and redirect
            login(request, user)
            messages.success(request, 'You have successfully logged in.')
            return redirect('base')  # Redirect to home after login
        else:
            # Increment login attempts on failed login
            user.profile.login_attempts += 1
            user.profile.save()
            messages.error(request, 'Invalid username or password.')

    return render(request, 'login.html')


def custom_logout(request):
    """Handle user logout."""
    if request.user.is_authenticated:
        # Update is_active field in the database
        with transaction.atomic():
            user = User.objects.get(username=request.user.username)
            user.is_active = False
            user.save()

        # Log out the user
        logout(request)
        messages.success(request, 'You have been logged out successfully.')

    return redirect('/')  # Redirect to homepage

# Password Reset Views
def generate_random_hash():
    """Generate a random SHA-1 hash."""
    random_value = str(random.getrandbits(256))
    return hashlib.sha1(random_value.encode()).hexdigest()

def generate_reset_token():
    """Generate a password reset token."""
    random_string = ''.join(random.choices(string.ascii_letters + string.digits, k=10))
    return hashlib.sha1(random_string.encode()).hexdigest()

def forgot_password(request):
    """Handle forgot password request."""
    if request.method == 'POST':
        email = request.POST.get('email')

        try:
            user = User.objects.get(email=email)
            token = hashlib.sha1(str(random.random()).encode('utf-8')).hexdigest()

            if hasattr(user, 'profile'):
                user.profile.reset_token = token
                user.profile.save()

                send_mail(
                    'Password Reset Request',
                    f'Use this token to reset your password: {token}',
                    'admin@yourwebsite.com',
                    [user.email],
                    fail_silently=False,
                )
                return HttpResponse("Password reset email sent.")
            else:
                return HttpResponse("User does not have a profile.", status=404)

        except User.DoesNotExist:
            return HttpResponse("Email not found.", status=404)

    return render(request, 'forgot_password.html')

def password_reset_confirm(request):
    """Confirm password reset using token."""
    if request.method == 'POST':
        email = request.POST.get('email')
        reset_token = request.POST.get('reset_token')
        new_password = request.POST.get('new_password')

        try:
            user = User.objects.get(email=email)
            if user.profile.password_reset_hash == reset_token:
                user.set_password(new_password)
                user.save()
                messages.success(request, 'Password reset successful.')
                return redirect('login')
            else:
                messages.error(request, 'Invalid token.')
        except User.DoesNotExist:
            messages.error(request, 'No user found with this email.')

    return render(request, 'password_reset_confirm.html')

# CRUD Operations for Clients
def add_client(request):
    """Add a new client to the database."""
    if request.method == 'POST':
        new_client_name = request.POST.get('new_client_name')
        new_client_email = request.POST.get('new_client_email')
        new_client_sin = request.POST.get('new_client_sin')

        # Insert the data into the new_client table
        with connection.cursor() as cursor:
            cursor.execute(
                "INSERT INTO new_client (new_client_name, new_client_email, new_client_sin) "
                "VALUES (%s, %s, %s)",
                [new_client_name, new_client_email, new_client_sin]
            )
        
        return redirect('/base')  # Redirect to the base page

    return render(request, 'add_client.html')

from django.contrib.auth.decorators import login_required

@login_required
def base_page(request):
    clients = NewClient.objects.all()
    print(clients)  # Check if clients are being fetched correctly
    for client in clients:
        print(client)  # Print individual client details for debugging
    return render(request, 'base.html', {'clients': clients})

# Static Page Views
def homepage(request):
    """Render the homepage."""
    return render(request, 'homepage.html')

def about(request):
    """Render the about page."""
    return render(request, 'about.html')

def change_password(request):
    """Render the change password page."""
    return render(request, 'change_password.html')

# Password Update View
def update_password(request):
    """Handle password update with validation."""
    if request.method == 'POST':
        old_password = request.POST['old_password']
        new_password = request.POST['new_password']
        confirm_password = request.POST['confirm_password']

        password_policy = load_password_policy()  # Load password policy

        # Validate the old password
        if not request.user.check_password(old_password):
            messages.error(request, "Old password is incorrect.")
            return render(request, 'update_password.html')

        # Check if new passwords match
        if new_password != confirm_password:
            messages.error(request, "New passwords do not match.")
            return render(request, 'update_password.html')

        # Validate the new password against the policy
        if not validate_password(new_password, password_policy):
            messages.error(request, "New password does not meet the requirements.")
            return render(request, 'update_password.html')

        # Update the password
        request.user.set_password(new_password)
        request.user.save()
        update_session_auth_hash(request, request.user)  # Important to keep the user logged in

        messages.success(request, "Your password has been updated successfully.")
        return redirect('base')  # Redirect to the desired page

    return render(request, 'update_password.html')

# Example usage of certificate verification (add this where relevant)
def verify_client_certificate(request):
    """Verify a client's digital certificate."""
    try:
        client_cert = load_certificate_from_file('certificates/client_certificate.pem')
        ca_cert = load_certificate_from_file('certificates/ca_certificate.pem')

        # Verify the client's certificate against the CA certificate
        if verify_certificate(client_cert, ca_cert):
            messages.success(request, "Certificate is valid.")
        else:
            messages.error(request, "Certificate verification failed.")

    except Exception as e:
        messages.error(request, f"Error verifying certificate: {str(e)}")

    return render(request, 'some_template.html')

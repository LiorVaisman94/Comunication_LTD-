# certificate_utils.py

from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives.serialization import load_pem_public_key

def load_certificate_from_file(file_path):
    """
    Load a digital certificate from a PEM file and return the certificate object.
    
    :param file_path: Path to the PEM file containing the certificate.
    :return: x509.Certificate object.
    """
    with open(file_path, 'rb') as cert_file:
        certificate = x509.load_pem_x509_certificate(cert_file.read(), default_backend())
    return certificate

def load_public_key_from_file(file_path):
    """
    Load a public key from a PEM file and return the public key object.
    
    :param file_path: Path to the PEM file containing the public key.
    :return: Public key object.
    """
    with open(file_path, 'rb') as key_file:
        key_data = key_file.read()
    return load_pem_public_key(key_data, backend=default_backend())

def verify_certificate(client_cert, ca_cert):
    """
    Verify a client certificate against a CA certificate.
    
    :param client_cert: The client certificate (x509.Certificate object).
    :param ca_cert: The CA certificate (x509.Certificate object).
    :return: True if the certificate is valid, False otherwise.
    """
    # Compare the issuer of the client to the subject of the CA
    issuer = client_cert.issuer
    if issuer == ca_cert.subject:
        ca_public_key = ca_cert.public_key()
        try:
            ca_public_key.verify(
                client_cert.signature,
                client_cert.tbs_certificate_bytes,
                padding.PKCS1v15(),
                hashes.SHA256()
            )
            return True
        except Exception as e:
            print(f"Certificate signature could not be verified: {e}")
    return False

from django.db import models

class NewClient(models.Model):
    idnew_client = models.IntegerField(primary_key=True)  # Define the primary key field as it is in your database
    new_client_name = models.CharField(max_length=45)
    new_client_email = models.EmailField(max_length=45)
    new_client_sin = models.CharField(max_length=45)

    class Meta:
        db_table = 'new_client'  # The exact name of your table in the database
        managed = False  # Indicates that Django should not create or modify this table

    def __str__(self):
        return f"{self.new_client_name} ({self.new_client_email})"

# Example of a Profile model to track login attempts
from django.db import models
from django.contrib.auth.models import User

class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.CASCADE)
    login_attempts = models.IntegerField(default=0)

    def __str__(self):
        return f'{self.user.username} Profile'

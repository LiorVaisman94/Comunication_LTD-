from django.contrib import admin
from django.urls import path
from . import views
from .views import custom_logout, update_password

urlpatterns = [
    # Admin page
    path('admin/', admin.site.urls),
    
    # Homepage and basic views
    path('', views.homepage, name='home'),  # Home page view
    path('about/', views.about, name='about'),  # About page view

    # Authentication-related views
    path('register/', views.register, name='register'),  # Registration page view
    path('login/', views.login_view, name='login'),  # Login page view
    path('logout/', custom_logout, name='logout'),  # Custom logout view
     # path('forgot-password/', views.forgot_password, name='forgot-password'),  # Forgot password view
    path('change-password/', views.change_password, name='change-password'),  # Change password view
    path('password-reset-confirm/', views.password_reset_confirm, name='password_reset_confirm'),  # Password reset confirm view
    
    # Password update view
    path('update_password/', views.update_password, name='update-password'),  # Change the URL pattern

    
    # Client-related views
    path('add-client/', views.add_client, name='add-client'),  # Add client page view
    
    # Base page view for testing or table display
    path('base/', views.base_page, name='base'),  # Base page view to show client table
]
